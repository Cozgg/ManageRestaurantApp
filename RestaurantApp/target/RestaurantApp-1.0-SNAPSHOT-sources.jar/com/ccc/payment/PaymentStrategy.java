/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ccc.payment;

/**
 *
 * @author Admin
 */
public interface PaymentStrategy {
    String pay(String orderId, long amount);
}
